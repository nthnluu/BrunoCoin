package id

type Config struct{}

func DefaultConfig() *Config {
	c := &Config{}
	return c
}
