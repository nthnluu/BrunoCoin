package test

import (
	"BrunoCoin/pkg"
	"BrunoCoin/pkg/block/tx"
	"BrunoCoin/pkg/block/tx/txi"
	"BrunoCoin/pkg/block/tx/txo"
	"BrunoCoin/pkg/wallet"
	"testing"
)

func TestWalletHndlTxReq(t *testing.T) {
	newNode := pkg.New(pkg.DefaultConfig(80234))
	txReq := &wallet.TxReq{
		PubK: newNode.Id.GetPublicKeyBytes(),
		Amt:  1,
		Fee:  1,
	}
	println(newNode.Wallet.LmnlTxs.TxQ.Len())
	if newNode.Wallet.LmnlTxs.TxQ.Len() != 0 {
		t.Fatal()
	}
	newNode.Wallet.HndlTxReq(txReq)
	if newNode.Wallet.LmnlTxs.TxQ.Len() != 0 {
		t.Fatal()
	}

}

func TestWalletChkTxs(t *testing.T) {
	newNode := pkg.New(pkg.DefaultConfig(80234))
	tx1 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{makeTxI(10, 0), makeTxI(10, 1), makeTxI(10, 2)},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	}

	newNode.Wallet.LmnlTxs.TxQ.Add(0, tx1)
	if newNode.Wallet.LmnlTxs.TxQ.Len() != 1 {
		t.Fatal()
	}
	pri, dups := newNode.Wallet.LmnlTxs.ChkTxs([]*tx.Transaction{tx1})
	if newNode.Wallet.LmnlTxs.TxQ.Len() != 0 {
		t.Fatal()
	}

	if len(pri) > 0 {
		t.Fatal()
	}

	if len(dups) != 1 {
		t.Fatal()
	}
}
