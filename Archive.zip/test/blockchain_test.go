package test

import (
	"BrunoCoin/pkg/block"
	"BrunoCoin/pkg/block/tx"
	"BrunoCoin/pkg/block/tx/txi"
	"BrunoCoin/pkg/block/tx/txo"
	"BrunoCoin/pkg/blockchain"
	"BrunoCoin/pkg/utils"
	"testing"
)

func makeBlockchain() *blockchain.Blockchain {
	return blockchain.New(blockchain.DefaultConfig())
}

func TestBCAdd(t *testing.T) {
	utils.SetDebug(true)
	var newBlockchain = makeBlockchain()
	tx1 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{makeTxI(10, 0), makeTxI(10, 1), makeTxI(10, 2)},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	}

	newBlock := &block.Block{
		Hdr:          block.Header{},
		Transactions: []*tx.Transaction{tx1},
	}

	if newBlockchain.Length() != 1 {
		t.Fatal()
	}
	newBlockchain.Add(newBlock)

	if newBlockchain.Length() != 2 {
		t.Fatal()
	}

	if newBlockchain.LastBlock.Block != newBlock {
		t.Fatal()
	}
}

func TestGetUTXOForAmt(t *testing.T) {
	utils.SetDebug(true)
	var newBlockchain = makeBlockchain()
	tx1 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{makeTxI(10, 0), makeTxI(10, 1), makeTxI(10, 2)},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	}

	newBlock := &block.Block{
		Hdr:          block.Header{},
		Transactions: []*tx.Transaction{tx1},
	}

	newBlockchain.Add(newBlock)
	utxoInfo, change, isEnough := newBlockchain.GetUTXOForAmt(uint32(20), "00000")

	if change != 5 {
		t.Fatal()
	}

	if utxoInfo[0].OutIdx != 0 {
		t.Fatal()
	}

	if len(utxoInfo) > 1 {
		t.Fatal()
	}

	if utxoInfo[0].Amt != 25 {
		t.Fatal()
	}

	if utxoInfo[0].TxHsh != tx1.Hash() {
		t.Fatal()
	}

	if !isEnough {
		t.Fatal()
	}

}