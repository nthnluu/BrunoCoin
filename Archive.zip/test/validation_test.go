package test

import (
	"BrunoCoin/pkg"
	"BrunoCoin/pkg/block/tx"
	"BrunoCoin/pkg/block/tx/txi"
	"BrunoCoin/pkg/block/tx/txo"
	"encoding/hex"
	"testing"
)

func TestChkTx(t *testing.T) {

}

func TestChkBlk(t *testing.T) {
	newNode := pkg.New(pkg.DefaultConfig(8000))
	tx1 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{&txi.TransactionInput{
			TransactionHash: "00000",
			OutputIndex:     0,
			UnlockingScript: "dwefdwe",
			Amount:          100,
		}},
		Outputs:  []*txo.TransactionOutput{&txo.TransactionOutput{
			Amount:        50,
			LockingScript: hex.EncodeToString(newNode.Id.GetPublicKeyBytes()),
			Liminal:       false,
		}},
		LockTime: 0,
	}
	tx2 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{makeTxI(10, 0), makeTxI(10, 1), makeTxI(10, 2)},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	}

	if newNode.ChkTx(tx1) {
		t.Fatal()
	}

	if newNode.ChkTx(tx2) {
		t.Fatal()
	}

}
