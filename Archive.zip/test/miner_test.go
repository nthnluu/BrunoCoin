package test

import (
	"BrunoCoin/pkg/block"
	"BrunoCoin/pkg/block/tx"
	"BrunoCoin/pkg/block/tx/txi"
	"BrunoCoin/pkg/block/tx/txo"
	"BrunoCoin/pkg/id"
	"BrunoCoin/pkg/miner"
	"BrunoCoin/pkg/utils"
	"encoding/hex"
	"math"
	"strconv"
	"testing"
)

func makeTxI(amt uint32, index uint32) *txi.TransactionInput {
	return &txi.TransactionInput{
		TransactionHash: "00000",
		OutputIndex:     index,
		UnlockingScript: "99999",
		Amount:          amt,
	}
}

func makeTxO(amt uint32) *txo.TransactionOutput {
	return &txo.TransactionOutput{
		Amount:        amt,
		LockingScript: "00000",
		Liminal:       false,
	}
}

func makeMiner() *miner.Miner {
	var newId, _ = id.CreateSimpleID()
	return miner.New(miner.DefaultConfig(4), newId)
}

func TestGetCBTx(t *testing.T) {
	utils.SetDebug(true)
	var newMiner = makeMiner()

	tx1 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{makeTxI(10, 0), makeTxI(10, 1), makeTxI(10, 2)},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	}

	tx2 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{makeTxI(12, 0), makeTxI(12, 1), makeTxI(12, 2)},
		Outputs:  []*txo.TransactionOutput{makeTxO(30)},
		LockTime: 0,
	}

	var txs = []*tx.Transaction{tx1, tx2}

	var cbtx = newMiner.GenCBTx(txs)

	// Check for no inputs
	if len(cbtx.Inputs) != 0 {
		t.Fatalf("CBTX should have no inputs.")
	}

	// Check for one output
	if len(cbtx.Outputs) != 1 {
		t.Fatalf("CBTX should have exactly one output.")
	}

	// Check is transaction is marked as coinbase tx
	if !cbtx.IsCoinbase() {
		t.Fatalf("CBTX should output a coinbase transaction.")
	}

	numTimesToHalf := newMiner.ChnLen.Load() / newMiner.Conf.SubsdyHlvRt

	if numTimesToHalf > newMiner.Conf.MxHlvgs {
		numTimesToHalf = newMiner.Conf.MxHlvgs
	}

	subsdy := float64(newMiner.Conf.InitSubsdy) * math.Pow(0.5, float64(numTimesToHalf))

	correctOutputAmt := (tx1.SumInputs() - tx1.SumOutputs()) + (tx2.SumInputs() - tx2.SumOutputs()) + uint32(subsdy)

	// Check for correct fee amount
	if cbtx.Outputs[0].Amount != correctOutputAmt {
		t.Fatalf("CBTX output amount should be " + strconv.Itoa(int(correctOutputAmt)) + ", instead the amount was " + strconv.Itoa(int(cbtx.Outputs[0].Amount)))
	}

	// Check for correct fee amount
	if cbtx.Outputs[0].LockingScript != hex.EncodeToString(newMiner.Id.GetPublicKeyBytes()) {
		t.Fatalf("CBTX output should be addressed to the public key of the miner.")
	}

}

func TestCalcPri(t *testing.T) {
	tx1 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{makeTxI(10, 0), makeTxI(10, 1), makeTxI(10, 2)},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	}

	tx2 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	}



	if miner.CalcPri(tx1) != (((tx1.SumInputs() - tx1.SumOutputs()) * 100) / tx1.Sz()) {
		t.Fatal()
	}

	if miner.CalcPri(tx2) != 1 {
		t.Fatal()
	}
}

func TestHndlTx(t *testing.T) {
	var newMiner = makeMiner()

	tx1 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{makeTxI(10, 0), makeTxI(10, 1), makeTxI(10, 2)},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	}

	tx2 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	}

	newMiner.StartMiner()
	newMiner.HndlTx(tx1)
	newMiner.HndlTx(tx2)

	if newMiner.TxP.Length() != 2 {
		t.Fatal()
	}
}

func TestChkTxs(t *testing.T) {
	var newMiner = makeMiner()

	tx1 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{makeTxI(10, 0), makeTxI(10, 1), makeTxI(10, 2)},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	}

	tx2 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	}

	tx3:= &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{makeTxI(10, 0)},
		Outputs:  []*txo.TransactionOutput{makeTxO(3)},
		LockTime: 0,
	}

	newMiner.HndlTx(tx1)
	newMiner.HndlTx(tx2)
	newMiner.HndlTx(tx3)

	if newMiner.TxP.Ct.Load() != uint32(3) {
		t.Fatal()
	}

	if newMiner.TxP.CurPri.Load() != (miner.CalcPri(tx1) + miner.CalcPri(tx2) + miner.CalcPri(tx3)) {
		t.Fatal()
	}
	pri := newMiner.TxP.CurPri.Load()
	newMiner.TxP.ChkTxs([]*tx.Transaction{tx1, tx2})

	pri = pri - miner.CalcPri(tx1) - miner.CalcPri(tx2)

	if newMiner.TxP.Length() != 1 {
		t.Fatal()
	}

	if newMiner.TxP.CurPri.Load() != pri {
		t.Fatal()
	}

	if newMiner.TxP.Ct.Load() != uint32(1) {
		t.Fatal()
	}
}

func TestHndlChckBlk(t *testing.T) {
	var newMiner = makeMiner()

	tx1 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{makeTxI(10, 0), makeTxI(10, 1), makeTxI(10, 2)},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	}

	tx2 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	}

	newMiner.HndlTx(tx1)
	newMiner.HndlTx(tx2)

	newBlock := &block.Block{
		Hdr:          block.Header{
			Ver:       0,
			PrvBlkHsh: "jgoiejrg",
			MrklRt:    "ergergerg",
			Timestamp: 0,
			DiffTarg:  "ergerger",
			Nonce:     0,
		},
		Transactions: []*tx.Transaction{tx1},
	}

	if newMiner.TxP.Length() != 2 {
		t.Fatal()
	}

	newMiner.HndlChkBlk(newBlock)

	if newMiner.TxP.Length() != 1 {
		t.Fatal()
	}

	newBlock1 := &block.Block{
		Hdr:          block.Header{
			Ver:       0,
			PrvBlkHsh: "jgoiejrg",
			MrklRt:    "ergergerg",
			Timestamp: 0,
			DiffTarg:  "ergerger",
			Nonce:     0,
		},
		Transactions: []*tx.Transaction{tx2},
	}

	newMiner.HndlChkBlk(newBlock1)
	if newMiner.TxP.Length() != 0 {
		t.Fatal()
	}
}

func TestHndlBlk(t *testing.T) {
	var newMiner = makeMiner()

	tx1 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{makeTxI(10, 0), makeTxI(10, 1), makeTxI(10, 2)},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	}

	tx2 := &tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	}

	newMiner.StartMiner()
	newMiner.HndlTx(tx1)
	newMiner.HndlTx(tx2)

	if newMiner.TxP.Length() != 2 {
		t.Fatal()
	}
}

func TestAdd(t *testing.T) {
	var newMiner1 = makeMiner()

	for i := 0; i < 50; i++ {
		pri := newMiner1.TxP.CurPri.Load()
		newTx := &tx.Transaction{
			Version:  0,
			Inputs:   []*txi.TransactionInput{makeTxI(10, 0), makeTxI(10, 1), makeTxI(10, 2)},
			Outputs:  []*txo.TransactionOutput{makeTxO(25)},
			LockTime: 0,
		}
		newMiner1.TxP.Add(newTx)

		if newMiner1.TxP.Ct.Load() != uint32(i + 1) {
			t.Fatal()
		}

		if newMiner1.TxP.CurPri.Load() != (pri + miner.CalcPri(newTx)) {
			t.Fatal()
		}
	}

	newMiner1.TxP.Add(&tx.Transaction{
		Version:  0,
		Inputs:   []*txi.TransactionInput{makeTxI(10, 0), makeTxI(10, 1), makeTxI(10, 2)},
		Outputs:  []*txo.TransactionOutput{makeTxO(25)},
		LockTime: 0,
	})

	if newMiner1.TxP.Length() != 50 {
		t.Fatal()
	}


}